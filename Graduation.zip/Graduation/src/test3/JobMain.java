package test3;
import org.apache.hadoop.conf.Configuration;  
import org.apache.hadoop.fs.Path;  
import org.apache.hadoop.io.Text;  
import org.apache.hadoop.mapreduce.Job;  
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;  
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;  
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

import com.sun.org.apache.bcel.internal.generic.NEW;

public class JobMain {  
	public static void main(String[] args) throws Exception{
		Configuration configuration = new Configuration();
		configuration.set("key.value.separator.in.input.line", "");  
		configuration.set("xmlinput.start", "<Server>");  
		configuration.set("xmlinput.end", "</Server>");  
		Job job = new Job(configuration, "xmlread-job");
		job.setJarByClass(JobMain.class);  
		job.setMapperClass(XMLMapper.class);  
		job.setMapOutputKeyClass(Text.class);  
		job.setMapOutputValueClass(Text.class);  
		job.setInputFormatClass(XMLInputFormat.class);  
		job.setNumReduceTasks(1);  
		job.setReducerClass(XMLReducer.class);  
		//job.setOutputFormatClass(XMLOutputFormat.class);  
		FileInputFormat.addInputPath(job, new Path(args[0]));  
		Path output = new Path(args[1]);
		FileOutputFormat.setOutputPath(job, output); 
		output.getFileSystem(configuration).delete(output, true);
		System.exit(job.waitForCompletion(true) ? 0: 1);  
	}  
}  