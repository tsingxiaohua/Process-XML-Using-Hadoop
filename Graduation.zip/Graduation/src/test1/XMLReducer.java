package test1;   
import java.io.IOException;  

import org.apache.hadoop.io.Text;  
import org.apache.hadoop.mapreduce.Reducer;  
  
public class XMLReducer extends Reducer<Text, Text, Text, Text>{  
    private Text val_ = new Text();  
    @Override  
    protected void reduce(Text key, Iterable<Text> value, Context context)  
            throws IOException, InterruptedException {  
        for(Text val: value) {  
            val_.set(val.toString());  
            context.write(key, val_);  
        }  
    }  
} 